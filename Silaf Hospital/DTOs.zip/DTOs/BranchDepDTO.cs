﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Silaf_Hospital.DTOs
{
    public class BranchDepDTO
    {
        public string BranchId { get; set; }
        public string DepartmentId { get; set; }
        public string? Notes { get; set; }
    }
}
