﻿namespace Silaf_Hospital.DTOs
{
    public class ClinicUpdateDTO
    {
        public string Id { get; set; }
        public string? Name { get; set; }
        public string? OpeningHours { get; set; }
        public string? DepartmentId { get; set; }
    }
}
