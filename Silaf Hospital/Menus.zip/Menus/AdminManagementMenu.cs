﻿using Silaf_Hospital.DTOs;
using Silaf_Hospital.Services;
using System;

namespace Silaf_Hospital.Menus
{
    public static class AdminManagementMenu
    {
        public static void Show(AdminService adminService)
        {
            while (true)
            {
                Console.Clear();
                Console.ForegroundColor = ConsoleColor.DarkYellow;
                Console.WriteLine("======= ADMIN MANAGEMENT =======");
                Console.ResetColor();

                Console.WriteLine("1. Add Admin");
                Console.WriteLine("2. View All Admins");
                Console.WriteLine("3. Update Admin");
                Console.WriteLine("4. Delete Admin");
                Console.WriteLine("5. Search by National ID");
                Console.WriteLine("6. Search by Name");
                Console.WriteLine("0. Back");

                Console.Write("\nChoose an option: ");
                string input = Console.ReadLine();

                switch (input)
                {
                    case "1":
                        AddAdmin(adminService);
                        break;
                    case "2":
                        adminService.ViewAllAdmins();
                        Console.ReadKey();
                        break;
                    case "3":
                        UpdateAdmin(adminService);
                        break;
                    case "4":
                        DeleteAdmin(adminService);
                        break;
                    case "5":
                        SearchById(adminService);
                        break;
                    case "6":
                        SearchByName(adminService);
                        break;
                    case "0":
                        return;
                    default:
                        Console.WriteLine("❌ Invalid option.");
                        Console.ReadKey();
                        break;
                }
            }
        }

        private static void AddAdmin(AdminService service)
        {
            UserInputDTO input = new UserInputDTO();

            Console.Write("Full Name: ");
            input.FullName = Console.ReadLine();

            Console.Write("Email: ");
            input.Email = Console.ReadLine();

            Console.Write("Password: ");
            input.Password = Console.ReadLine();

            Console.Write("Phone Number: ");
            input.PhoneNumber = Console.ReadLine();

            Console.Write("Gender: ");
            input.Gender = Console.ReadLine();

            Console.Write("Age: ");
            input.Age = int.Parse(Console.ReadLine());

            Console.Write("National ID: ");
            input.NationalID = Console.ReadLine();

            service.AddAdmin(input);
            Console.ReadKey();
        }

        private static void UpdateAdmin(AdminService service)
        {
            Console.Write("Enter National ID of admin to update: ");
            string nationalId = Console.ReadLine();

            UserInputDTO input = new UserInputDTO();
            input.NationalID = nationalId;

            Console.Write("New Full Name: ");
            input.FullName = Console.ReadLine();

            Console.Write("New Email: ");
            input.Email = Console.ReadLine();

            Console.Write("New Password: ");
            input.Password = Console.ReadLine();

            Console.Write("New Phone Number: ");
            input.PhoneNumber = Console.ReadLine();

            Console.Write("New Gender: ");
            input.Gender = Console.ReadLine();

            Console.Write("New Age: ");
            input.Age = int.Parse(Console.ReadLine());

            service.UpdateAdmin(nationalId, input);
            Console.ReadKey();
        }

        private static void DeleteAdmin(AdminService service)
        {
            Console.Write("Enter National ID of admin to delete: ");
            string id = Console.ReadLine();
            service.DeleteAdmin(id);
            Console.ReadKey();
        }

        private static void SearchById(AdminService service)
        {
            Console.Write("Enter National ID: ");
            string id = Console.ReadLine();

            var admin = service.GetAdminById(id);
            if (admin != null)
            {
                Console.WriteLine($"✅ Found: {admin.FullName}, {admin.Email}");
            }
            else
            {
                Console.WriteLine("❌ Admin not found.");
            }

            Console.ReadKey();
        }

        private static void SearchByName(AdminService service)
        {
            Console.Write("Enter Full Name: ");
            string name = Console.ReadLine();

            var admin = service.GetAdminByName(name);
            if (admin != null)
            {
                Console.WriteLine($"✅ Found: {admin.FullName}, {admin.Email}");
            }
            else
            {
                Console.WriteLine("❌ Admin not found.");
            }

            Console.ReadKey();
        }
    }
}
