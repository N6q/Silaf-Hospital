﻿namespace Silaf_Hospital.DTOs
{
    public class DepartmentInputDTO
    {
        public string Name { get; set; }
        public string BranchId { get; set; }
        public string? Specialty { get; set; }
    }
}
