﻿namespace Silaf_Hospital.DTOs
{
    public class ClinicInputDTO
    {
        public string Name { get; set; }
        public string BranchId { get; set; }
        public string DepartmentId { get; set; }
        public string OpeningHours { get; set; }
    }
}
