﻿namespace Silaf_Hospital.DTOs
{
    public class PrescriptionInputDTO
    {
        public string MedicineName { get; set; }
        public string Dosage { get; set; }
        public int DurationDays { get; set; }
    }
}
