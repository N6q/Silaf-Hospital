﻿namespace Silaf_Hospital.DTOs
{
    public class NotificationUpdateDTO
    {
        public string Id { get; set; }
        public bool MarkAsRead { get; set; }
    }
}
