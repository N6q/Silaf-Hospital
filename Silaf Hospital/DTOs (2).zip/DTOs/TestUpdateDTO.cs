﻿namespace Silaf_Hospital.DTOs
{
    public class TestUpdateDTO
    {
        public string Id { get; set; }
        public string Result { get; set; }
    }
}
