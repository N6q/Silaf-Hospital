﻿namespace Silaf_Hospital.DTOs
{
    public class PrescriptionOutputDTO
    {
        public string MedicineName { get; set; }
        public string Dosage { get; set; }
        public int DurationDays { get; set; }
    }
}
