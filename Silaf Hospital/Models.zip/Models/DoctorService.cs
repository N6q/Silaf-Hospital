﻿using Silaf_Hospital.DTOs;
using Silaf_Hospital.Models;
using Silaf_Hospital.FilesHandling;
using System;
using System.Collections.Generic;

namespace Silaf_Hospital.Services
{
    public class DoctorService : IDoctorService
    {
        private List<Doctor> doctors = new List<Doctor>();
        private readonly DoctorFileHandler fileHandler = new DoctorFileHandler();

        public DoctorService()
        {
            LoadFromFile();
        }

        public void AddDoctor(DoctorInputDTO input)
        {
            Doctor doctor = new Doctor();
            doctor.FullName = input.FullName;
            doctor.Email = input.Email;
            doctor.Password = input.Password;
            doctor.PhoneNumber = input.PhoneNumber;
            doctor.NationalId = input.NationalId;
            doctor.Specialization = input.Specialization;
            doctor.ClinicId = input.ClinicId;

            doctors.Add(doctor);
            SaveToFile();
            Console.WriteLine("✅ Doctor added successfully.");
        }

        public bool EmailExists(string email)
        {
            foreach (Doctor doctor in doctors)
            {
                if (doctor.Email == email)
                {
                    return true;
                }
            }
            return false;
        }

        public List<Doctor> GetAllDoctors()
        {
            return doctors;
        }

        public List<Doctor> GetDoctorByBrancDep(string branchId, string departmentId)
        {
            List<Doctor> result = new List<Doctor>();
            foreach (Doctor doctor in doctors)
            {
                if (doctor.ClinicId == branchId + "-" + departmentId)
                {
                    result.Add(doctor);
                }
            }
            return result;
        }

        public Doctor GetDoctorByEmail(string email)
        {
            foreach (Doctor doctor in doctors)
            {
                if (doctor.Email == email)
                {
                    return doctor;
                }
            }
            return null;
        }

        public Doctor GetDoctorById(string id)
        {
            foreach (Doctor doctor in doctors)
            {
                if (doctor.NationalId == id)
                {
                    return doctor;
                }
            }
            return null;
        }

        public Doctor GetDoctorByName(string name)
        {
            foreach (Doctor doctor in doctors)
            {
                if (doctor.FullName == name)
                {
                    return doctor;
                }
            }
            return null;
        }

        public DoctorOutputDTO GetDoctorData(string docName, string docId)
        {
            Doctor doctor = GetDoctorById(docId);
            if (doctor != null && doctor.FullName == docName)
            {
                DoctorOutputDTO dto = new DoctorOutputDTO();
                dto.FullName = doctor.FullName;
                dto.Email = doctor.Email;
                dto.PhoneNumber = doctor.PhoneNumber;
                dto.NationalId = doctor.NationalId;
                dto.Specialization = doctor.Specialization;
                dto.ClinicId = doctor.ClinicId;
                return dto;
            }
            return null;
        }

        public List<DoctorOutputDTO> GetDoctorsByBranchName(string branchName)
        {
            List<DoctorOutputDTO> results = new List<DoctorOutputDTO>();
            foreach (Doctor doctor in doctors)
            {
                if (doctor.ClinicId.StartsWith(branchName + "-"))
                {
                    DoctorOutputDTO dto = new DoctorOutputDTO();
                    dto.FullName = doctor.FullName;
                    dto.Email = doctor.Email;
                    dto.PhoneNumber = doctor.PhoneNumber;
                    dto.NationalId = doctor.NationalId;
                    dto.Specialization = doctor.Specialization;
                    dto.ClinicId = doctor.ClinicId;
                    results.Add(dto);
                }
            }
            return results;
        }

        public List<DoctorOutputDTO> GetDoctorsByDepartmentName(string departmentName)
        {
            List<DoctorOutputDTO> results = new List<DoctorOutputDTO>();
            foreach (Doctor doctor in doctors)
            {
                if (doctor.ClinicId.EndsWith("-" + departmentName))
                {
                    DoctorOutputDTO dto = new DoctorOutputDTO();
                    dto.FullName = doctor.FullName;
                    dto.Email = doctor.Email;
                    dto.PhoneNumber = doctor.PhoneNumber;
                    dto.NationalId = doctor.NationalId;
                    dto.Specialization = doctor.Specialization;
                    dto.ClinicId = doctor.ClinicId;
                    results.Add(dto);
                }
            }
            return results;
        }

        public void UpdateDoctor(Doctor doctor)
        {
            for (int i = 0; i < doctors.Count; i++)
            {
                if (doctors[i].NationalId == doctor.NationalId)
                {
                    doctors[i] = doctor;
                    SaveToFile();
                    Console.WriteLine("✅ Doctor updated.");
                    return;
                }
            }
            Console.WriteLine("❌ Doctor not found.");
        }

        public void UpdateDoctorDetails(DoctorUpdateDTO input)
        {
            Doctor doctor = GetDoctorById(input.NationalId);
            if (doctor != null)
            {
                doctor.FullName = input.FullName;
                doctor.Email = input.Email;
                doctor.Password = input.Password;
                doctor.PhoneNumber = input.PhoneNumber;
                doctor.Specialization = input.Specialization;
                doctor.ClinicId = input.ClinicId;

                SaveToFile();
                Console.WriteLine("✅ Doctor updated via DTO.");
            }
            else
            {
                Console.WriteLine("❌ Doctor not found.");
            }
        }

        public DoctorOutputDTO GetDoctorDetailsById(string id)
        {
            Doctor doctor = GetDoctorById(id);
            if (doctor != null)
            {
                DoctorOutputDTO dto = new DoctorOutputDTO();
                dto.FullName = doctor.FullName;
                dto.Email = doctor.Email;
                dto.PhoneNumber = doctor.PhoneNumber;
                dto.NationalId = doctor.NationalId;
                dto.Specialization = doctor.Specialization;
                dto.ClinicId = doctor.ClinicId;
                return dto;
            }
            return null;
        }

        public void ToggleAvailability(string nationalId)
        {
            Doctor doctor = GetDoctorById(nationalId);
            if (doctor != null)
            {
                doctor.IsAvailable = !doctor.IsAvailable;
                SaveToFile();
                Console.WriteLine(" Availability toggled: " + (doctor.IsAvailable ? "Available" : "Unavailable"));
            }
            else
            {
                Console.WriteLine(" Doctor not found.");
            }
        }


        public List<DoctorOutputDTO> GetAvailableDoctors()
        {
            List<DoctorOutputDTO> result = new List<DoctorOutputDTO>();
            foreach (Doctor doctor in doctors)
            {
                if (doctor.IsAvailable)
                {
                    DoctorOutputDTO dto = new DoctorOutputDTO();
                    dto.FullName = doctor.FullName;
                    dto.Email = doctor.Email;
                    dto.PhoneNumber = doctor.PhoneNumber;
                    dto.NationalId = doctor.NationalId;
                    dto.Specialization = doctor.Specialization;
                    dto.ClinicId = doctor.ClinicId;
                    dto.IsAvailable = true;
                    result.Add(dto);
                }
            }
            return result;
        }

        public void SaveToFile()
        {
            fileHandler.SaveDoctors(doctors);
        }

        public void LoadFromFile()
        {
            doctors = fileHandler.LoadDoctors();
            if (doctors == null)
            {
                doctors = new List<Doctor>();
            }
        }

        public bool DeleteDoctor(string id)
        {
            Doctor doctor = GetDoctorById(id);
            if (doctor != null)
            {
                doctors.Remove(doctor);
                SaveToFile();
                Console.WriteLine("✅ Doctor deleted.");
                return true;
            }

            Console.WriteLine("❌ Doctor not found.");
            return false;
        }
    }
}
