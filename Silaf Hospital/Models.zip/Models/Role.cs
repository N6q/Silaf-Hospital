﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Silaf_Hospital.Models
{
    public enum Role
    {
        Patient,
        Doctor,
        Admin,
        SuperAdmin
    }
}